<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About Us</title>
</head>
<body>
	<h1>ABOUT</h1>

	<h3>Tupac - About</h3>

	<h1>"Forge Your Strength, Define Your Power"</h1>

	<p>Welcome to Tupac Club, where iron meets determination 
	and sweat transforms intosuccess. We are more than 
	just a gym; we are a community dedicated to helping 
	you achieve your fitness goals, no matter where you 
	are on your journey. Whether you're a beginner or a 
	seasoned athlete, our state-of-the-art facilities 
	and expert trainers are here to support you every 
	step of the way. Join us and discover the strength 
	within you. This is more than a workout; it's a 
	lifestyle.</p>

	<h3>Founder</h3>
	<h5>Dawrin Darryl Jean E. Largoza</h5>
	<h6>Former Body Building Champion</h6>


	<h3>Trainor</h3>
	<h5>Spencer Z> Nacario</h5>
	<h6>Senior Trainer</h6>
</body>
</html>