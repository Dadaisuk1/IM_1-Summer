<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Contact Us</title>
</head>
<body>

	<h3>CONTACT US</h3>

	<h1>NEED ANY HELP? FEEL FREE TO CONTACT US.</h1>

	<form>
		<label for="name">Name</label>
		<input type="text" name="name" id="name">
		<br>
		<label for="email">Email</label>
		<input type="text" name="gmail" id="gmail">
		<br>
		<label for="phone">Phone</label>
		<input type="text" name="phone" id="phone">
		<br>
		<label for="subject">Subject</label>
		<input type="text" name="subject" id="subject">
		<br>
		<label for="message">Message</label>
		<input type="text" name="message" id="message">
		<br>
		<button type="submit">Submit Now</button>
	</form>

	<h2>Phone:</h2>

	<a href="#">09123456789</a>
	<br>
	<a href="#">09246810126</a>

	<h2>Email:</h2>
	<a href="#">largoza@adonis.com</a>
	<br>
	<a href="#">nacario@gmail.com</a>

	<h2>Address:</h2>
	<a href="#">Moalboal, Cebu</a>
	<br>
	<a href="#">Talisay, Cebu</a>

</body>
</html>